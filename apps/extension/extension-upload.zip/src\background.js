/**
 * HawkEye-Cue Background Service Worker
 * Handles API calls from content scripts (avoids CORS).
 */

const API_BASE = 'https://29p0xwb5v8.execute-api.us-east-1.amazonaws.com';

chrome.runtime.onMessage.addListener(function(message, sender, sendResponse) {
  if (message.type === 'PING') {
    sendResponse({ pong: true });
    return false;
  }

  if (message.type === 'GET_KEYWORDS') {
    chrome.storage.local.get(['keywords'], function(result) {
      if (result.keywords && result.keywords.length > 0) {
        sendResponse({ keywords: result.keywords });
      } else {
        // Try to fetch from API
        chrome.storage.local.get(['authToken'], function(authResult) {
          if (!authResult.authToken) {
            sendResponse({ keywords: [] });
            return;
          }
          fetch(API_BASE + '/keywords', {
            headers: { 'Authorization': 'Bearer ' + authResult.authToken }
          })
          .then(function(res) { return res.json(); })
          .then(function(data) {
            var keywords = (Array.isArray(data) ? data : data.keywords || []).map(function(k) { return k.keyword || k; });
            chrome.storage.local.set({ keywords: keywords });
            sendResponse({ keywords: keywords });
          })
          .catch(function() { sendResponse({ keywords: [] }); });
        });
      }
    });
    return true;
  }

  // ─── HawkEye Radar: real-time opportunity scoring ───
  if (message.type === 'SCORE_POST') {
    var sd = message.data;
    chrome.storage.local.get(['authToken', 'tokenExpiry', 'refreshToken', 'tradeName'], function(authResult) {
      var token = authResult.authToken;
      if (!token) { sendResponse({ success: false, error: 'Not logged in' }); return; }
      var trade = authResult.tradeName || '';

      // Fetch + cache the user's trade once so scoring is trade-aware
      if (!trade) {
        fetch(API_BASE + '/profile', { headers: { 'Authorization': 'Bearer ' + token } })
          .then(function(r) { return r.ok ? r.json() : null; })
          .then(function(p) {
            var tn = p && (p.tradeName || (p.trade && p.trade.name)) || '';
            if (tn) { trade = tn; chrome.storage.local.set({ tradeName: tn }); }
          })
          .catch(function() {});
      }

      function doScore(t) {
        fetch(API_BASE + '/radar/score', {
          method: 'POST',
          headers: { 'Authorization': 'Bearer ' + t, 'Content-Type': 'application/json' },
          body: JSON.stringify({ postText: sd.postText || '', tradeName: trade, group: sd.group || '' })
        })
        .then(function(res) {
          if (res.status === 401 && authResult.refreshToken) {
            // Refresh and retry
            fetch('https://cognito-idp.us-east-1.amazonaws.com/', {
              method: 'POST',
              headers: { 'Content-Type': 'application/x-amz-json-1.1', 'X-Amz-Target': 'AWSCognitoIdentityProviderService.InitiateAuth' },
              body: JSON.stringify({ AuthFlow: 'REFRESH_TOKEN_AUTH', ClientId: '2cr45bt815hr68i0j021murak', AuthParameters: { REFRESH_TOKEN: authResult.refreshToken } })
            })
            .then(function(rr) { return rr.json(); })
            .then(function(rd) {
              if (rd.AuthenticationResult && rd.AuthenticationResult.IdToken) {
                var nt = rd.AuthenticationResult.IdToken;
                chrome.storage.local.set({ authToken: nt, tokenExpiry: Date.now() + 3600000 });
                fetch(API_BASE + '/radar/score', { method: 'POST', headers: { 'Authorization': 'Bearer ' + nt, 'Content-Type': 'application/json' }, body: JSON.stringify({ postText: sd.postText || '', tradeName: authResult.tradeName || '', group: sd.group || '' }) })
                  .then(function(r2) { return r2.json(); })
                  .then(function(j2) { sendResponse({ success: true, result: j2.result }); })
                  .catch(function(e2) { sendResponse({ success: false, error: e2.message }); });
              } else { sendResponse({ success: false, error: 'auth' }); }
            })
            .catch(function() { sendResponse({ success: false, error: 'auth' }); });
          } else if (res.ok) {
            return res.json().then(function(j) { sendResponse({ success: true, result: j.result }); });
          } else {
            sendResponse({ success: false, error: 'score failed' });
          }
        })
        .catch(function(e) { sendResponse({ success: false, error: e.message }); });
      }
      doScore(token);
    });
    return true;
  }

  // ─── Hawk Memory: recall prior interactions with a person ───
  if (message.type === 'GET_MEMORY') {
    var md = message.data || {};
    chrome.storage.local.get(['authToken'], function(authResult) {
      var token = authResult.authToken;
      if (!token || !md.name) { sendResponse({ success: false }); return; }
      fetch(API_BASE + '/radar/memory?name=' + encodeURIComponent(md.name), {
        headers: { 'Authorization': 'Bearer ' + token }
      })
      .then(function(res) { return res.ok ? res.json() : null; })
      .then(function(j) { sendResponse({ success: true, memory: j && j.memory ? j.memory : null }); })
      .catch(function() { sendResponse({ success: false }); });
    });
    return true;
  }

  // ─── Hawk Memory: record an interaction with a person ───
  if (message.type === 'SAVE_MEMORY') {
    var smd = message.data || {};
    chrome.storage.local.get(['authToken'], function(authResult) {
      var token = authResult.authToken;
      if (!token || !smd.personName) { sendResponse({ success: false }); return; }
      fetch(API_BASE + '/radar/memory', {
        method: 'POST',
        headers: { 'Authorization': 'Bearer ' + token, 'Content-Type': 'application/json' },
        body: JSON.stringify({ personName: smd.personName, kind: smd.kind || 'note', note: smd.note || '', group: smd.group || '', platform: smd.platform || '', postUrl: smd.postUrl || '' })
      })
      .then(function(res) { sendResponse({ success: res.ok }); })
      .catch(function() { sendResponse({ success: false }); });
    });
    return true;
  }

  if (message.type === 'SAVE_LEAD') {
    var d = message.data;
    
    // Always get fresh token — refresh if needed
    chrome.storage.local.get(['authToken', 'tokenExpiry', 'refreshToken'], function(authResult) {
      var token = authResult.authToken;
      
      function doSave(t) {
        fetch(API_BASE + '/opportunities', {
          method: 'POST',
          headers: { 'Authorization': 'Bearer ' + t, 'Content-Type': 'application/json' },
          body: JSON.stringify({
            keywordId: 'extension-detected',
            sourceContent: d.postContent || 'No content',
            sourcePlatform: d.platform || 'facebook',
            sourceUrl: d.postUrl || 'https://facebook.com',
            sourceAuthor: d.authorName || 'Unknown'
          })
        })
        .then(function(res) {
          if (res.status === 401 && authResult.refreshToken) {
            // Token expired — try refresh
            fetch('https://cognito-idp.us-east-1.amazonaws.com/', {
              method: 'POST',
              headers: { 'Content-Type': 'application/x-amz-json-1.1', 'X-Amz-Target': 'AWSCognitoIdentityProviderService.InitiateAuth' },
              body: JSON.stringify({ AuthFlow: 'REFRESH_TOKEN_AUTH', ClientId: '2cr45bt815hr68i0j021murak', AuthParameters: { REFRESH_TOKEN: authResult.refreshToken } })
            })
            .then(function(rr) { return rr.json(); })
            .then(function(rd) {
              if (rd.AuthenticationResult && rd.AuthenticationResult.IdToken) {
                var newToken = rd.AuthenticationResult.IdToken;
                chrome.storage.local.set({ authToken: newToken, tokenExpiry: Date.now() + 3600000 });
                // Retry with new token
                fetch(API_BASE + '/opportunities', {
                  method: 'POST',
                  headers: { 'Authorization': 'Bearer ' + newToken, 'Content-Type': 'application/json' },
                  body: JSON.stringify({ keywordId: 'extension-detected', sourceContent: d.postContent || 'No content', sourcePlatform: d.platform || 'facebook', sourceUrl: d.postUrl || 'https://facebook.com', sourceAuthor: d.authorName || 'Unknown' })
                })
                .then(function(r2) { return r2.ok ? r2.json().then(function(j) { sendResponse({ success: true, result: j }); }) : r2.text().then(function(t2) { sendResponse({ success: false, error: 'API ' + r2.status }); }); })
                .catch(function(e2) { sendResponse({ success: false, error: e2.message }); });
              } else {
                sendResponse({ success: false, error: 'Token refresh failed — please re-login in extension popup' });
              }
            })
            .catch(function() { sendResponse({ success: false, error: 'Token refresh failed' }); });
          } else if (res.ok) {
            return res.json().then(function(result) { sendResponse({ success: true, result: result }); });
          } else {
            return res.text().then(function(text) { sendResponse({ success: false, error: 'API ' + res.status }); });
          }
        })
        .catch(function(err) { sendResponse({ success: false, error: err.message }); });
      }
      
      // If token is expired, refresh first
      if (authResult.tokenExpiry && Date.now() >= authResult.tokenExpiry && authResult.refreshToken) {
        fetch('https://cognito-idp.us-east-1.amazonaws.com/', {
          method: 'POST',
          headers: { 'Content-Type': 'application/x-amz-json-1.1', 'X-Amz-Target': 'AWSCognitoIdentityProviderService.InitiateAuth' },
          body: JSON.stringify({ AuthFlow: 'REFRESH_TOKEN_AUTH', ClientId: '2cr45bt815hr68i0j021murak', AuthParameters: { REFRESH_TOKEN: authResult.refreshToken } })
        })
        .then(function(rr) { return rr.json(); })
        .then(function(rd) {
          if (rd.AuthenticationResult && rd.AuthenticationResult.IdToken) {
            var newToken = rd.AuthenticationResult.IdToken;
            chrome.storage.local.set({ authToken: newToken, tokenExpiry: Date.now() + 3600000 });
            doSave(newToken);
          } else { doSave(token); }
        })
        .catch(function() { doSave(token); });
      } else {
        doSave(token);
      }
    });
    return true;
  }

  if (message.type === 'SAVE_APPRECIATION') {
    var d2 = message.data;
    
    chrome.storage.local.get(['authToken', 'tokenExpiry', 'refreshToken'], function(authResult) {
      var token2 = authResult.authToken || d2.authToken;
      
      function doSaveAppreciation(t) {
        fetch(API_BASE + '/appreciations', {
          method: 'POST',
          headers: { 'Authorization': 'Bearer ' + t, 'Content-Type': 'application/json' },
          body: JSON.stringify({ taggerName: d2.taggerName || 'Unknown', platform: d2.platform || 'facebook', postContent: d2.postContent || 'No content', postUrl: d2.postUrl || '' })
        })
        .then(function(res) {
          if (res.status === 401 && authResult.refreshToken) {
            fetch('https://cognito-idp.us-east-1.amazonaws.com/', {
              method: 'POST',
              headers: { 'Content-Type': 'application/x-amz-json-1.1', 'X-Amz-Target': 'AWSCognitoIdentityProviderService.InitiateAuth' },
              body: JSON.stringify({ AuthFlow: 'REFRESH_TOKEN_AUTH', ClientId: '2cr45bt815hr68i0j021murak', AuthParameters: { REFRESH_TOKEN: authResult.refreshToken } })
            })
            .then(function(rr) { return rr.json(); })
            .then(function(rd) {
              if (rd.AuthenticationResult && rd.AuthenticationResult.IdToken) {
                var newToken = rd.AuthenticationResult.IdToken;
                chrome.storage.local.set({ authToken: newToken, tokenExpiry: Date.now() + 3600000 });
                fetch(API_BASE + '/appreciations', { method: 'POST', headers: { 'Authorization': 'Bearer ' + newToken, 'Content-Type': 'application/json' }, body: JSON.stringify({ taggerName: d2.taggerName || 'Unknown', platform: d2.platform || 'facebook', postContent: d2.postContent || 'No content', postUrl: d2.postUrl || '' }) })
                .then(function(r2) { return r2.ok ? r2.json().then(function(j) { sendResponse({ success: true, result: j }); }) : sendResponse({ success: false, error: 'API ' + r2.status }); })
                .catch(function() { sendResponse({ success: false, error: 'Retry failed' }); });
              } else { sendResponse({ success: false, error: 'Token refresh failed' }); }
            })
            .catch(function() { sendResponse({ success: false, error: 'Token refresh failed' }); });
          } else if (res.ok) {
            return res.json().then(function(result) { sendResponse({ success: true, result: result }); });
          } else {
            sendResponse({ success: false, error: 'API ' + res.status });
          }
        })
        .catch(function(err) { sendResponse({ success: false, error: err.message }); });
      }
      
      if (authResult.tokenExpiry && Date.now() >= authResult.tokenExpiry && authResult.refreshToken) {
        fetch('https://cognito-idp.us-east-1.amazonaws.com/', {
          method: 'POST',
          headers: { 'Content-Type': 'application/x-amz-json-1.1', 'X-Amz-Target': 'AWSCognitoIdentityProviderService.InitiateAuth' },
          body: JSON.stringify({ AuthFlow: 'REFRESH_TOKEN_AUTH', ClientId: '2cr45bt815hr68i0j021murak', AuthParameters: { REFRESH_TOKEN: authResult.refreshToken } })
        })
        .then(function(rr) { return rr.json(); })
        .then(function(rd) {
          if (rd.AuthenticationResult && rd.AuthenticationResult.IdToken) {
            var newToken = rd.AuthenticationResult.IdToken;
            chrome.storage.local.set({ authToken: newToken, tokenExpiry: Date.now() + 3600000 });
            doSaveAppreciation(newToken);
          } else { doSaveAppreciation(token2); }
        })
        .catch(function() { doSaveAppreciation(token2); });
      } else {
        doSaveAppreciation(token2);
      }
    });
    return true;
  }

  if (message.type === 'CHECK_AUTH') {
    chrome.storage.local.get(['authToken', 'tokenExpiry'], function(result) {
      sendResponse({ authenticated: !!(result.authToken && result.tokenExpiry && Date.now() < result.tokenExpiry) });
    });
    return true;
  }

  if (message.type === 'SYNC_WINGMAN') {
    var wmData = message.data || {};
    var updates = {};
    if (wmData.wingmanKeywords) updates.wingmanKeywords = wmData.wingmanKeywords;
    if (wmData.wingmanName) updates.wingmanName = wmData.wingmanName;
    if (Object.keys(updates).length > 0) {
      chrome.storage.local.set(updates, function() {
        sendResponse({ success: true });
      });
    } else {
      sendResponse({ success: true });
    }
    return true;
  }

  if (message.type === 'GET_STATS') {
    chrome.storage.local.get(['authToken'], function(authResult) {
      if (!authResult.authToken) { sendResponse({ leadsFound: 0, appreciations: 0 }); return; }
      Promise.all([
        fetch(API_BASE + '/opportunities/stats', { headers: { 'Authorization': 'Bearer ' + authResult.authToken } }).then(function(r) { return r.json(); }).catch(function() { return {}; }),
        fetch(API_BASE + '/appreciations', { headers: { 'Authorization': 'Bearer ' + authResult.authToken } }).then(function(r) { return r.json(); }).catch(function() { return { items: [] }; })
      ]).then(function(results) {
        var stats = results[0].stats || results[0];
        sendResponse({ leadsFound: stats.total || 0, appreciations: (results[1].items || []).length });
      });
    });
    return true;
  }

  return false;
});

// Refresh keywords every 15 minutes
chrome.alarms.create('refreshKeywords', { periodInMinutes: 15 });

// Poll team deal notifications every 5 minutes
chrome.alarms.create('checkTeamNotifications', { periodInMinutes: 5 });

chrome.alarms.onAlarm.addListener(function(alarm) {
  if (alarm.name === 'refreshKeywords') {
    chrome.storage.local.get(['authToken'], function(result) {
      if (!result.authToken) return;
      // Refresh regular keywords
      fetch(API_BASE + '/keywords', { headers: { 'Authorization': 'Bearer ' + result.authToken } })
      .then(function(res) { return res.json(); })
      .then(function(data) {
        var keywords = (Array.isArray(data) ? data : data.keywords || []).map(function(k) { return k.keyword || k; });
        chrome.storage.local.set({ keywords: keywords });
      })
      .catch(function() {});
      // Refresh wingman keywords from profile preferences
      fetch(API_BASE + '/profile/preferences', { headers: { 'Authorization': 'Bearer ' + result.authToken } })
      .then(function(res) { return res.json(); })
      .then(function(prefs) {
        var updates = {};
        if (prefs.wingmanKeywords && Array.isArray(prefs.wingmanKeywords)) {
          updates.wingmanKeywords = prefs.wingmanKeywords;
        }
        if (prefs.wingmanName) {
          updates.wingmanName = prefs.wingmanName;
        }
        if (Object.keys(updates).length > 0) {
          chrome.storage.local.set(updates);
        }
      })
      .catch(function() {});
    });
  }

  // Team deal notification badge
  if (alarm.name === 'checkTeamNotifications') {
    chrome.storage.local.get(['authToken'], function(result) {
      if (!result.authToken) {
        chrome.action.setBadgeText({ text: '' });
        return;
      }
      fetch(API_BASE + '/team/notifications', {
        headers: { 'Authorization': 'Bearer ' + result.authToken }
      })
      .then(function(res) { return res.json(); })
      .then(function(data) {
        var count = (data.notifications || []).filter(function(n) { return !n.dismissed; }).length;
        chrome.action.setBadgeText({ text: count > 0 ? String(count) : '' });
        chrome.action.setBadgeBackgroundColor({ color: '#22c55e' });
      })
      .catch(function() {
        chrome.action.setBadgeText({ text: '' });
      });
    });
  }

  // Auto-refresh token before it expires
  if (alarm.name === 'refreshToken') {
    chrome.storage.local.get(['refreshToken', 'tokenExpiry'], function(result) {
      if (!result.refreshToken) return;
      // Only refresh if token expires within 10 minutes
      if (result.tokenExpiry && Date.now() < result.tokenExpiry - (10 * 60 * 1000)) return;

      fetch('https://cognito-idp.us-east-1.amazonaws.com/', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-amz-json-1.1',
          'X-Amz-Target': 'AWSCognitoIdentityProviderService.InitiateAuth',
        },
        body: JSON.stringify({
          AuthFlow: 'REFRESH_TOKEN_AUTH',
          ClientId: '2cr45bt815hr68i0j021murak',
          AuthParameters: { REFRESH_TOKEN: result.refreshToken },
        }),
      })
      .then(function(res) { return res.json(); })
      .then(function(data) {
        if (data.AuthenticationResult && data.AuthenticationResult.IdToken) {
          chrome.storage.local.set({
            authToken: data.AuthenticationResult.IdToken,
            tokenExpiry: Date.now() + ((data.AuthenticationResult.ExpiresIn || 3600) * 1000),
          });
          console.log('[HawkEye] Token refreshed automatically');
        }
      })
      .catch(function(e) { console.log('[HawkEye] Token refresh failed:', e); });
    });
  }
});

// Create token refresh alarm (runs every 45 minutes — token lasts 60 min)
chrome.alarms.create('refreshToken', { periodInMinutes: 45 });

// ─── External message listener (receives token from hawkeyecue.com website) ───
chrome.runtime.onMessageExternal.addListener(function(message, sender, sendResponse) {
  if (message.type === 'ACTIVATE_EXTENSION' && message.token) {
    chrome.storage.local.set({
      authToken: message.token,
      refreshToken: message.refreshToken || null,
      tokenExpiry: Date.now() + (3600 * 1000), // 1 hour
      userEmail: message.email || '',
    }, function() {
      // Fetch keywords immediately
      fetch(API_BASE + '/keywords', { headers: { 'Authorization': 'Bearer ' + message.token } })
      .then(function(res) { return res.json(); })
      .then(function(data) {
        var keywords = (Array.isArray(data) ? data : data.keywords || []).map(function(k) { return k.keyword || k; });
        chrome.storage.local.set({ keywords: keywords });
      })
      .catch(function() {});
      // Fetch wingman keywords from profile preferences
      fetch(API_BASE + '/profile/preferences', { headers: { 'Authorization': 'Bearer ' + message.token } })
      .then(function(res) { return res.json(); })
      .then(function(prefs) {
        var updates = {};
        if (prefs.wingmanKeywords && Array.isArray(prefs.wingmanKeywords)) {
          updates.wingmanKeywords = prefs.wingmanKeywords;
        }
        if (prefs.wingmanName) {
          updates.wingmanName = prefs.wingmanName;
        }
        if (Object.keys(updates).length > 0) {
          chrome.storage.local.set(updates);
        }
      })
      .catch(function() {});
      sendResponse({ success: true });
    });
    return true;
  }
  if (message.type === 'CHECK_EXTENSION') {
    sendResponse({ installed: true, version: chrome.runtime.getManifest().version });
    return false;
  }
});
